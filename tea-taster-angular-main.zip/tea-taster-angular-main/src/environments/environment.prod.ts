export const environment = {
  production: true,
  dataService: 'https://cs-demo-api.herokuapp.com',
};
