export * from './shared.module';
export * from './rating/rating.component';
